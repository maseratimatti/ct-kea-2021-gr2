create database trust_quiz; 
# Create database er brugt til at oprette vores database sæt, som vi kalder for trust_quiz
use trust_quiz;
# use er brugt til vælge det oprettede database sæt 
create table Brugerne(
Bruger_ID int(7),
b_mail varchar(70),
b_password varchar(50),
b_navn char(20),
b_efternavn char(50));
# create table er brugt til at oprette en tabel, med de forskellige kolonner. 
# kolonnerne er dannet ud fra vores rationelle tabel i excel
# Varchar, char og int er brugt til at definere hvor mange karakter input eller tal input tabellen må have
# Import data wizard er brugt til at importere vores data fra en csv fil
# Primary keys er oprettet ved at trykke på indstillinger ude i "Schemas" under den relevante tabel
# Foreign keys er ligeledes brugt ved at ændre det i indstillinger i "Schemas", så de hænger sammen 
# Samtlige tabeller er oprettet efter denne fremgangs metode
#Vi har brugt alter table til at kombinere brugerne tabellen med resultat ID


create table Adm(
a_ID int(7),
a_navn char(20),
a_password varchar(20),
a_email varchar(70));

create table Kliste(
K_navn char(250),
k_id varchar(1));

create table Kkat(
K_kat char(50),
k_id varchar(1));

create table Quiz(
S_id varchar(20),
Grafisk_Design varchar(1),
Programmering varchar(1),
Social_Media varchar(1),
S_quiz varchar(250));

create table Resultat(
R_ID varchar(20),
R_Score varchar(3),
k_id varchar(7));

alter table Brugerne
add R_id varchar(20);


