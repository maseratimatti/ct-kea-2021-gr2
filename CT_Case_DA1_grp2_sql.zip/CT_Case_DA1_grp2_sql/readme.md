DA1 - Gruppe 2 - KEA - Coders Trust Case
Af: Marco Jin, Mathias Hyttel, Mathias Vedsø, Muslim Zaurbekov, Oliver Williams 

!!!! Installations Guide til Trust_Quiz Database !!!!


Det er påkrævet at der allerede er installeret en SQL server, og et program til at køre SQL serveren i, vi har brugt mySQL workbench. 

For at upload CSV datafilerne der er brugt til databasen skal følgende process gøres i mySQL Workbench:

- Åben DDL filen, DA1_grp2_QuizDB.sql
- Kør scriptet, så databasen bliver indlæst i Schemas
- I Schemas, åben trust_quiz databasen, og åben fanen "Tables"
- Højre klik på en tabel, f.eks. "Adm" og vælg "Table Data Import Wizard"
- Vælg den valgte fil til den valgte table, f.eks. hvis "Adm" tabellen valgt, skal Adm.csv filen vælges. Csv filerne findes i den vedlagte mappe "CSV Filer database"
- Vælg "Use existing table", og sørg for trust.quiz.adm er valgt, hvis tabellen adm er valgt.
- Kolonerne skulle automatisk passe med kolonerne i scriptet, hvis ikke kan det rettes til i configure import settings.
- Tryk næste for at importere data filen ind i SQL
- Tryk Finish når dataen er importere
- Dette skal gøres i samtlige af tabellerne

Når Dataen er importeren, kan det andet script, DA1_grp2_QuizDML.sql åbnes og køres i mySQL workbench.

