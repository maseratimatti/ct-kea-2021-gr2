use trust_quiz;
# Database er hentet ind fra den tidligere oprettet database "trust_quiz"
select * from brugerne
where R_ID IS NOT NULL;
#Not null er brugt til at filtrere not null værdierne fra i resultat ID
select brugerne.b_mail, resultat.k_ID
from Brugerne
inner join resultat on brugerne.R_ID = resultat.R_ID;
#Der er lavet en join på brugernes mail, samt resultatets kategori ID. Den er sammenlagt ved at sige at 
#resultat ID i brugerne er det samme som resultat ID i resultaterne. 
select kliste.K_navn, kkat.k_kat
from kliste
inner join kkat on kliste.k_ID = kkat.k_ID;
#Der er lavet en join på kursuslistens navne med kategorierne fra kkat listen.
#Den joiner kursus ID fra kliste med kursus ID fra kkat 
select k_navn
from kliste
order by k_navn;
#Select from og order by er brugt til at give admin en alfabetisk rækkefølge over de kursuser
#Coderstrust har i deres system 


